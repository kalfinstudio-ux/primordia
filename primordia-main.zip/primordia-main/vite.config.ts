import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      outDir: 'dist',
      sourcemap: false,
    },
    server: {
      // Codespaces / tunnel / HP di jaringan yang sama mengakses lewat nama host lain; tanpa ini
      // Vite menjawab "Blocked request. This host is not allowed".
      allowedHosts: true,
      // Jangan diam-diam pindah ke 3001/3002 (link port Codespace jadi tidak cocok).
      strictPort: true,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
