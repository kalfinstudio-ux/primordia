import React, { useState } from 'react';
import {
  DEFAULT_SETTINGS,
  type DifficultyLevel,
  type GameSettings,
  type GraphicsPreset,
  type HandMode,
  type KeyBindings,
  type LanguageCode,
} from '../game/config';
import { gameState, saveSettingsToLocal, setScreen } from '../game/core/state';
import { pushCloudSettings } from '../game/net/settingsSync';
import { clearAllGameStorage, writeStorage } from '../game/utils/storage';
import { eventBus } from '../game/core/eventBus';
import { t } from '../game/utils/i18n';
import { ConfirmDialog } from './ConfirmDialog';
import { usePWAInstall } from './pwaInstall';

type TabId = 'display' | 'audio' | 'controls' | 'game' | 'general';

/** Kategori menu: urutan = urutan tampil di sidebar. */
const CATEGORIES: Array<{ id: TabId; icon: string }> = [
  { id: 'display', icon: '🖥️' },
  { id: 'audio', icon: '🔊' },
  { id: 'controls', icon: '🎮' },
  { id: 'game', icon: '⚔️' },
  { id: 'general', icon: '⚙️' },
];

export function SettingsScreen() {
  const [tab, setTab] = useState<TabId>('display');
  const [draft, setDraft] = useState<GameSettings>(() => JSON.parse(JSON.stringify(gameState.settings)));
  const [listeningKey, setListeningKey] = useState<keyof KeyBindings | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const { canInstall, promptInstall } = usePWAInstall();

  const returnTarget = gameState.previousScreen === 'pause' ? 'pause' : 'menu';

  const applyAndSave = (next: GameSettings) => {
    setDraft(next);
    saveSettingsToLocal(next);
  };

  const applyPreset = (preset: GraphicsPreset) => {
    const viewDistance = preset === 'low' ? 85 : preset === 'medium' ? 125 : 175;
    const shadows = preset !== 'low';
    const particles = preset !== 'low';
    applyAndSave({
      ...draft,
      graphics: { ...draft.graphics, preset, viewDistance, shadows, particles },
    });
  };

  const handleKeyCapture = (action: keyof KeyBindings) => {
    setListeningKey(action);
    const listener = (e: KeyboardEvent) => {
      e.preventDefault();
      window.removeEventListener('keydown', listener);
      setListeningKey(null);
      applyAndSave({
        ...draft,
        controls: {
          ...draft.controls,
          keys: { ...draft.controls.keys, [action]: e.code },
        },
      });
    };
    window.addEventListener('keydown', listener, { once: true });
  };

  const set = <K extends keyof GameSettings>(key: K, patch: Partial<GameSettings[K]>) =>
    applyAndSave({ ...draft, [key]: { ...(draft[key] as object), ...patch } } as unknown as GameSettings);

  const segBtn = (active: boolean) =>
    `min-h-[40px] rounded-lg border px-3 text-xs sm:text-sm font-medium transition-colors ${
      active
        ? 'border-orange-500 bg-orange-600/20 text-orange-200'
        : 'border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800'
    }`;

  const actionBtn = 'min-h-[44px] w-full rounded-lg border border-stone-700 bg-stone-900 px-4 py-2 text-left text-sm font-medium text-stone-200 hover:bg-stone-800';

  return (
    <main className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4" style={{ backgroundColor: 'rgba(11, 9, 8, 0.88)' }}>
      <section className="flex max-h-[96dvh] w-full max-w-4xl flex-col overflow-hidden rounded-xl border border-stone-800 bg-[#14100e] shadow-2xl">
        <div className="flex items-center justify-between border-b border-stone-800 px-4 py-2.5 sm:px-5 sm:py-3.5">
          <h2 className="font-display text-xl font-semibold text-stone-100 sm:text-3xl">{t('settings.title')}</h2>
          <button
            type="button"
            onClick={() => setScreen(returnTarget)}
            className="min-h-[40px] rounded-lg bg-orange-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-500"
          >
            {t('settings.saveClose')}
          </button>
        </div>

        <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
          {/* Kategori: sidebar di layar lebar/landscape, baris geser di layar sempit */}
          <nav
            aria-label={t('settings.title')}
            className="primordia-scroll flex shrink-0 gap-1 overflow-x-auto border-b border-stone-800 px-3 py-2 sm:w-44 sm:flex-col sm:overflow-x-visible sm:overflow-y-auto sm:border-b-0 sm:border-r sm:p-3"
          >
            {CATEGORIES.map(({ id, icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                aria-current={tab === id ? 'page' : undefined}
                className={`flex min-h-[40px] shrink-0 items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1 text-left text-xs font-medium transition-colors sm:text-sm ${
                  tab === id ? 'bg-orange-600 text-white' : 'text-stone-300 hover:bg-stone-800 hover:text-white'
                }`}
              >
                <span aria-hidden="true">{icon}</span>
                {t(`settings.cat.${id}`)}
              </button>
            ))}
          </nav>

          <div className="primordia-scroll min-h-0 flex-1 space-y-4 overflow-y-auto p-3 sm:p-5">
            {tab === 'display' && (
              <>
                <Section title={t('settings.sec.quality')} hint={t('settings.hint.quality')}>
                  <div>
                    <div className="text-xs font-medium text-stone-300">{t('settings.preset')}</div>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                      {(['low', 'medium', 'high'] as GraphicsPreset[]).map((p) => (
                        <button key={p} type="button" onClick={() => applyPreset(p)} className={segBtn(draft.graphics.preset === p)}>
                          {t(`settings.presets.${p}`)}
                        </button>
                      ))}
                    </div>
                  </div>
                  <SliderRow
                    id="view-dist"
                    label={t('settings.viewDistance')}
                    valueText={`${draft.graphics.viewDistance} m`}
                    min={70}
                    max={220}
                    step={5}
                    value={draft.graphics.viewDistance}
                    onChange={(v) => set('graphics', { viewDistance: v })}
                  />
                  <ToggleRow label={t('settings.shadows')} enabled={draft.graphics.shadows} onToggle={() => set('graphics', { shadows: !draft.graphics.shadows })} />
                  <ToggleRow label={t('settings.particles')} enabled={draft.graphics.particles} onToggle={() => set('graphics', { particles: !draft.graphics.particles })} />
                  <div>
                    <div className="text-xs font-medium text-stone-300">{t('settings.fpsLimit')}</div>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                      {[30, 60, 120].map((fps) => (
                        <button key={fps} type="button" onClick={() => set('graphics', { fpsLimit: fps })} className={`font-mono-tabular ${segBtn(draft.graphics.fpsLimit === fps)}`}>
                          {fps} FPS
                        </button>
                      ))}
                    </div>
                  </div>
                </Section>

                <Section title={t('settings.sec.hud')} hint={t('settings.hint.hud')}>
                  <ToggleRow label={t('settings.showHud')} enabled={draft.gameplay.showHud} onToggle={() => set('gameplay', { showHud: !draft.gameplay.showHud })} />
                  <SliderRow
                    id="hud-scale"
                    label={t('settings.hudScale')}
                    valueText={`${Math.round(draft.controls.hudScale * 100)}%`}
                    min={0.75}
                    max={1.25}
                    step={0.05}
                    value={draft.controls.hudScale}
                    onChange={(v) => set('controls', { hudScale: v })}
                  />
                </Section>
              </>
            )}

            {tab === 'audio' && (
              <Section title={t('settings.sec.volume')} hint={t('settings.hint.volume')}>
                {(
                  [
                    ['master', 'masterVol'],
                    ['music', 'musicVol'],
                    ['sfx', 'sfxVol'],
                    ['ambient', 'ambientVol'],
                  ] as const
                ).map(([field, labelKey]) => (
                  <SliderRow
                    key={field}
                    id={`vol-${field}`}
                    label={t(`settings.${labelKey}`)}
                    valueText={`${Math.round(draft.audio[field] * 100)}%`}
                    min={0}
                    max={1}
                    step={0.05}
                    value={draft.audio[field]}
                    onChange={(v) => set('audio', { [field]: v } as Partial<GameSettings['audio']>)}
                  />
                ))}
              </Section>
            )}

            {tab === 'controls' && (
              <>
                <Section title={t('settings.sec.camera')} hint={t('settings.hint.camera')}>
                  <SliderRow
                    id="cam-sens"
                    label={t('settings.sensitivity')}
                    valueText={`${draft.controls.sensitivity.toFixed(1)}x`}
                    min={0.4}
                    max={2.0}
                    step={0.1}
                    value={draft.controls.sensitivity}
                    onChange={(v) => set('controls', { sensitivity: v })}
                  />
                </Section>

                <Section title={t('settings.sec.touch')} hint={t('settings.hint.touch')}>
                  <SliderRow
                    id="joy-size"
                    label={t('settings.joystickSize')}
                    valueText={`${Math.round(draft.controls.joystickSize * 100)}%`}
                    min={0.8}
                    max={1.4}
                    step={0.1}
                    value={draft.controls.joystickSize}
                    onChange={(v) => set('controls', { joystickSize: v })}
                  />
                  <SliderRow
                    id="btn-opacity"
                    label={t('settings.buttonOpacity')}
                    valueText={`${Math.round(draft.controls.buttonOpacity * 100)}%`}
                    min={0.45}
                    max={1.0}
                    step={0.05}
                    value={draft.controls.buttonOpacity}
                    onChange={(v) => set('controls', { buttonOpacity: v })}
                  />
                  <div>
                    <div className="text-xs font-medium text-stone-300">{t('settings.handMode')}</div>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {(['right', 'left'] as HandMode[]).map((mode) => (
                        <button key={mode} type="button" onClick={() => set('controls', { handMode: mode })} className={segBtn(draft.controls.handMode === mode)}>
                          {t(mode === 'right' ? 'settings.handRight' : 'settings.handLeft')}
                        </button>
                      ))}
                    </div>
                  </div>
                  <ToggleRow
                    label={t('settings.preferLandscape')}
                    enabled={draft.controls.preferLandscape}
                    onToggle={() => set('controls', { preferLandscape: !draft.controls.preferLandscape })}
                  />
                </Section>

                <Section title={t('settings.sec.keyboard')} hint={t('settings.hint.keyboard')}>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {(Object.keys(draft.controls.keys) as Array<keyof KeyBindings>).map((action) => (
                      <div key={action} className="flex items-center justify-between rounded-lg border border-stone-800 bg-stone-900/70 px-3 py-2">
                        <span className="text-sm capitalize text-stone-300">{action}</span>
                        <button
                          type="button"
                          onClick={() => handleKeyCapture(action)}
                          className="font-mono-tabular min-h-[34px] rounded border border-stone-700 bg-stone-950 px-3 text-xs text-orange-300 hover:border-orange-500"
                        >
                          {listeningKey === action ? t('settings.pressKey') : draft.controls.keys[action]}
                        </button>
                      </div>
                    ))}
                  </div>
                </Section>
              </>
            )}

            {tab === 'game' && (
              <>
                <Section title={t('settings.sec.difficulty')} hint={t('settings.hint.difficulty')}>
                  <div className="grid grid-cols-3 gap-2">
                    {(['explorer', 'survivor', 'hadean'] as DifficultyLevel[]).map((d) => {
                      const key = d === 'explorer' ? 'diffExplorer' : d === 'survivor' ? 'diffSurvivor' : 'diffHadean';
                      return (
                        <button key={d} type="button" onClick={() => set('gameplay', { difficulty: d })} className={`min-h-[44px] ${segBtn(draft.gameplay.difficulty === d)}`}>
                          {t(`newGame.${key}`)}
                        </button>
                      );
                    })}
                  </div>
                </Section>

                <Section title={t('settings.sec.units')} hint={t('settings.hint.units')}>
                  <div className="grid grid-cols-2 gap-2">
                    {(['metric', 'imperial'] as const).map((u) => (
                      <button key={u} type="button" onClick={() => set('gameplay', { units: u })} className={`min-h-[44px] ${segBtn(draft.gameplay.units === u)}`}>
                        {t(`settings.${u}`)}
                      </button>
                    ))}
                  </div>
                </Section>
              </>
            )}

            {tab === 'general' && (
              <>
                <Section title={t('settings.sec.language')} hint={t('settings.hint.language')}>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        ['id', 'Bahasa Indonesia'],
                        ['en', 'English'],
                      ] as Array<[LanguageCode, string]>
                    ).map(([code, label]) => (
                      <button key={code} type="button" onClick={() => applyAndSave({ ...draft, language: code })} className={`min-h-[44px] ${segBtn(draft.language === code)}`}>
                        {label}
                      </button>
                    ))}
                  </div>
                </Section>

                <Section title={t('settings.sec.app')} hint={t('settings.hint.app')}>
                  {canInstall && (
                    <button
                      type="button"
                      onClick={() => void promptInstall()}
                      className="min-h-[44px] w-full rounded-lg border border-orange-600/70 bg-orange-950/30 px-4 py-2 text-left text-sm font-medium text-orange-200 hover:bg-orange-950/60"
                    >
                      {t('menu.installApp')}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={async () => {
                      const ok = await pushCloudSettings();
                      eventBus.emit('toast:show', {
                        text: ok ? t('pause.savedToast') : t('auth.notConfigured'),
                        type: ok ? 'success' : 'warn',
                      });
                    }}
                    className={actionBtn}
                  >
                    {t('settings.syncNow')}
                  </button>
                </Section>

                <Section title={t('settings.sec.reset')} hint={t('settings.hint.reset')}>
                  <button
                    type="button"
                    onClick={() => {
                      gameState.onboardingDone = false;
                      writeStorage('onboarding_done', false);
                      setScreen('onboarding');
                    }}
                    className={actionBtn}
                  >
                    {t('settings.resetOnboarding')}
                  </button>
                  <button type="button" onClick={() => applyAndSave(JSON.parse(JSON.stringify(DEFAULT_SETTINGS)))} className={actionBtn}>
                    {t('settings.reset')}
                  </button>
                </Section>

                <Section title={t('settings.sec.danger')} hint={t('settings.hint.danger')} danger>
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="min-h-[44px] w-full rounded-lg border border-red-900/60 bg-red-950/30 px-4 py-2 text-left text-sm font-medium text-red-300 hover:bg-red-950/60"
                  >
                    {t('settings.clearLocalData')}
                  </button>
                </Section>
              </>
            )}
          </div>
        </div>
      </section>

      <ConfirmDialog
        open={confirmClear}
        title={t('settings.confirmClearTitle')}
        body={t('settings.confirmClearBody')}
        onCancel={() => setConfirmClear(false)}
        onConfirm={() => {
          clearAllGameStorage();
          setConfirmClear(false);
          applyAndSave(JSON.parse(JSON.stringify(DEFAULT_SETTINGS)));
        }}
      />
    </main>
  );
}

/** Kartu pengelompokan: judul + penjelasan singkat + isi. */
function Section({
  title,
  hint,
  danger = false,
  children,
}: {
  title: string;
  hint?: string;
  danger?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`rounded-xl border p-3 sm:p-4 ${danger ? 'border-red-900/50 bg-red-950/10' : 'border-stone-800 bg-stone-900/40'}`}>
      <h3 className={`text-sm font-semibold sm:text-base ${danger ? 'text-red-300' : 'text-orange-300'}`}>{title}</h3>
      {hint && <p className="mt-0.5 text-[11px] leading-snug text-stone-400 sm:text-xs">{hint}</p>}
      <div className="mt-3 space-y-4">{children}</div>
    </div>
  );
}

function ToggleRow({ label, enabled, onToggle }: { label: string; enabled: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-stone-200">{label}</span>
      <button
        type="button"
        onClick={onToggle}
        className={`min-h-[38px] rounded-lg px-4 text-sm font-medium ${
          enabled ? 'bg-orange-600 text-white' : 'bg-stone-800 text-stone-300'
        }`}
      >
        {enabled ? t('common.on') : t('common.off')}
      </button>
    </div>
  );
}

function SliderRow({
  id,
  label,
  valueText,
  min,
  max,
  step,
  value,
  onChange,
}: {
  id: string;
  label: string;
  valueText: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (val: number) => void;
}) {
  return (
    <div>
      <div className="flex justify-between text-sm text-stone-300">
        <label htmlFor={id}>{label}</label>
        <span className="font-mono-tabular">{valueText}</span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 w-full accent-orange-600"
      />
    </div>
  );
}
