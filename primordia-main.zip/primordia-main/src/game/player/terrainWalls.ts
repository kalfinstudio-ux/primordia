/**
 * Tabrakan dinding medan (tebing). Fungsi murni supaya bisa dites tanpa three.js.
 *
 * Masalah lama: pemblokiran lereng hanya aktif bila tanah naik >0,45 m dalam SATU langkah fisika
 * (±0,09 m gerak), jadi hampir tidak pernah aktif dan karakter "menembus" tebing. Di sini lereng
 * dinilai dari rasio naik/jalan, dan saat di udara karakter tidak boleh masuk ke dalam tanah.
 */

export type HeightFn = (x: number, z: number) => number;

export const WALL_RULES = {
  /** Naik/jalan maksimum saat berjalan (tan 48° ≈ 1,11). Di atas ini = dinding. */
  maxClimbGradient: 1.11,
  /** Anak tangga yang selalu boleh dinaiki (m) — supaya batu kecil tidak menghalangi. */
  stepUp: 0.38,
  /** Toleransi kaki di udara sebelum dianggap menabrak tanah (m). */
  airSkin: 0.3,
} as const;

export interface WallResult {
  x: number;
  z: number;
  blocked: boolean;
}

/** True bila langkah (fromX,fromZ)→(toX,toZ) masuk ke dinding medan. */
export function isWallBlocked(
  height: HeightFn,
  fromX: number,
  fromZ: number,
  toX: number,
  toZ: number,
  feetY: number,
  grounded: boolean
): boolean {
  const run = Math.hypot(toX - fromX, toZ - fromZ);
  if (run < 1e-6) return false;
  const groundTo = height(toX, toZ);
  if (!grounded) {
    // Di udara: kaki tidak boleh berada di bawah permukaan tanah tujuan.
    return groundTo > feetY + WALL_RULES.airSkin;
  }
  // Nilai kemiringan dari tinggi yang DIPEROLEH dalam jarak LOOK m ke depan (bukan per langkah
  // fisika yang cuma ±0,09 m), supaya dinding curam terdeteksi sedangkan anak tangga kecil lolos.
  const LOOK = 0.6;
  const groundFrom = height(fromX, fromZ);
  const dirX = (toX - fromX) / run;
  const dirZ = (toZ - fromZ) / run;
  const aheadH = Math.max(groundTo, height(fromX + dirX * LOOK, fromZ + dirZ * LOOK), height(toX + dirX * 0.3, toZ + dirZ * 0.3));
  const aheadRise = aheadH - groundFrom;
  if (aheadRise <= WALL_RULES.stepUp) return false;
  return aheadRise / LOOK > WALL_RULES.maxClimbGradient;
}

/**
 * Selesaikan gerak horizontal terhadap dinding medan: coba gerak penuh, lalu geser sepanjang
 * sumbu X saja atau Z saja (meluncur di sepanjang dinding), lalu berhenti.
 */
export function resolveTerrainWall(
  height: HeightFn,
  fromX: number,
  fromZ: number,
  toX: number,
  toZ: number,
  feetY: number,
  grounded: boolean
): WallResult {
  if (!isWallBlocked(height, fromX, fromZ, toX, toZ, feetY, grounded)) {
    return { x: toX, z: toZ, blocked: false };
  }
  const dx = toX - fromX;
  const dz = toZ - fromZ;
  // Coba sumbu dengan gerak lebih besar dulu.
  const tryX = () =>
    Math.abs(dx) > 1e-6 && !isWallBlocked(height, fromX, fromZ, toX, fromZ, feetY, grounded)
      ? { x: toX, z: fromZ, blocked: true }
      : null;
  const tryZ = () =>
    Math.abs(dz) > 1e-6 && !isWallBlocked(height, fromX, fromZ, fromX, toZ, feetY, grounded)
      ? { x: fromX, z: toZ, blocked: true }
      : null;
  const slid = Math.abs(dx) >= Math.abs(dz) ? tryX() ?? tryZ() : tryZ() ?? tryX();
  return slid ?? { x: fromX, z: fromZ, blocked: true };
}
