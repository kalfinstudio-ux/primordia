import test from 'node:test';
import assert from 'node:assert/strict';
import { SpatialHashGrid, resolveCapsuleObstacles } from './core/spatialHash';
import { isWallBlocked, resolveTerrainWall } from './player/terrainWalls';

// Dataran rata di y=0 dengan dinding tegak (naik 6 m dalam 1 m) mulai x=10.
const wall = (x: number, _z: number) => (x < 10 ? 0 : Math.min(6, (x - 10) * 6));
const flat = () => 0;
const ramp = (x: number) => Math.max(0, x) * 0.5; // lereng ±27°, boleh didaki

test('dinding curam menahan pemain yang berjalan ke arahnya', () => {
  let x = 9;
  for (let i = 0; i < 200; i++) {
    const r = resolveTerrainWall(wall, x, 0, x + 0.1, 0, 0, true);
    x = r.x;
  }
  assert.ok(x < 10.2, `pemain menembus dinding, x=${x}`);
});

test('pemain meluncur di sepanjang dinding, bukan berhenti total', () => {
  const r = resolveTerrainWall(wall, 9.95, 0, 10.2, 0.1, 0, true);
  assert.equal(r.blocked, true);
  assert.equal(r.x, 9.95);
  assert.equal(r.z, 0.1);
});

test('lereng landai dan anak tangga kecil boleh dilalui', () => {
  assert.equal(isWallBlocked(ramp, 2, 0, 2.1, 0, 1, true), false);
  const step = (x: number) => (x < 5 ? 0 : 0.3);
  assert.equal(isWallBlocked(step, 4.95, 0, 5.05, 0, 0, true), false);
});

test('di udara pemain tidak boleh masuk ke dalam tebing', () => {
  assert.equal(isWallBlocked(wall, 9.9, 0, 10.1, 0, 0.2, false), true);
  assert.equal(isWallBlocked(wall, 9.9, 0, 10.1, 0, 7, false), false);
  assert.equal(isWallBlocked(flat, 0, 0, 1, 0, 0, false), false);
});

test('query spatial hash menemukan collider besar yang pusatnya di sel tetangga', () => {
  const grid = new SpatialHashGrid(8);
  // pusat di x=8.1 (sel 1), pemain di x=5.0 (sel 0) dengan jangkauan 0,5: lingkaran 2,5 menyentuh.
  grid.insert({ id: 'big', x: 8.1, z: 0, radius: 2.6, yMin: -1, yMax: 3, kind: 'structure' });
  grid.insert({ id: 'far', x: 40, z: 0, radius: 0.5, yMin: -1, yMax: 3, kind: 'rock' });
  const hits = grid.queryRadius(5.0, 0, 0.5);
  assert.deepEqual(hits.map((h) => h.id), ['big']);
  const solved = resolveCapsuleObstacles(5.0, 0, 0, 0.45, 1.75, hits);
  assert.ok(Math.hypot(solved.x - 8.1, solved.z) >= 3.0);
});
